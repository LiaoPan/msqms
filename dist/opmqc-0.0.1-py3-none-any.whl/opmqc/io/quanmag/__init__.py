# -*- coding: utf-8 -*-
"""QuanMag raw data reader."""

from .mag import read_raw_mag