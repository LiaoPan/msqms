# -*- coding: utf-8 -*-
"""OPM-MEG Preprocessing Pipeline
including:
1. filter
    - band filter
    - notch filter
2. HFC
3. SSS?
"""

