# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   Description :
   Author :       LiaoPan
   date：          2023/10/16 19:17
-------------------------------------------------
   Change Activity:
                   2023/10/16:
-------------------------------------------------
"""
__author__ = 'LiaoPan'

from opmqc.utils.utils import format_timedelta