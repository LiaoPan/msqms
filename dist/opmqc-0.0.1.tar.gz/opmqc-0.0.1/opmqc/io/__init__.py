# -*- coding: utf-8 -*-
"""IO module for read OPM raw data."""

from .quanmag import read_raw_mag